var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'b03704074',
applicationName: 'apollo-lambda-app',
appUid: 'pTldfhx3zD8D2dwpS2',
tenantUid: 'M30fj0ldmnCB7YNmHk',
deploymentUid: '8bd4c02d-da84-40f7-94f9-f7ebd60498e9',
serviceName: 'apollo-lambda',
stageName: 'dev',
pluginVersion: '3.2.1'})
const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-graphql', timeout: 6}
try {
  const userHandler = require('./graphql.js')
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
