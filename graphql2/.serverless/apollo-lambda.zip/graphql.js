// graphql.js
const { ApolloServer} = require('apollo-server-lambda');
const typeDefs = require('./schema');
const resolvers = require('./resolvers');
const TodoAPI = require('./todo.js');

// Construct a schema, using GraphQL schema language
// const typeDefs = gql`
//   type Query {
//     hello: String
//   }
// `;

// Provide resolver functions for your schema fields
// const resolvers = {
//   Query: {
//     hello: () => 'Hey world!',
//   },
// };

const server = 
    new ApolloServer({ 
        typeDefs,
        resolvers,
        dataSources: () => ({
            todoAPI: new TodoAPI()
        })
    });

exports.graphqlHandler = server.createHandler({
    cors: {
      origin: '*',
      credentials: true,
    },
});