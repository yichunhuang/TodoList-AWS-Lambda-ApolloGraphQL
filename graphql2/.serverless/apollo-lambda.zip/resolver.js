module.exports = {
    Query: {
      todos: (_, __, { dataSources }) =>
        dataSources.todoAPI.getAllTodos(),
      todo: (_, { id }, { dataSources }) =>
        dataSources.todoAPI.getTodoById({ todoId: id })
    }
  };