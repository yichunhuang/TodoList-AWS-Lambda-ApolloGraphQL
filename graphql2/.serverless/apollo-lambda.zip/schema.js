const { gql } = require('apollo-server');

const typeDefs = gql`
  # Your schema will go here
  type Query {
    todos: [Todo]!
    todo(id: ID!): Todo
  }
  type Todo {
    id: ID!
    title: String
    description: String
  }
  type Mutation {
    # if false, booking trips failed -- check errors
    bookTrips(launchIds: [ID]!): TripUpdateResponse!
  
    # if false, cancellation failed -- check errors
    cancelTrip(launchId: ID!): TripUpdateResponse!
  
    login(email: String): String # login token
  }
`;

module.exports = typeDefs;