const { RESTDataSource } = require('apollo-datasource-rest');

class TodoAPI extends RESTDataSource {
  constructor() {
    super();
    this.baseURL = 'https://9pfinhxi47.execute-api.us-east-2.amazonaws.com/prod/';
  }
  async getAllTodos() {
    const response = await this.get('todos');
    return Array.isArray(response)
      ? response.map(todo => this.launchReducer(todo))
      : [];
  }

  todoReducer(todo) {
    return {
      id: launch.id,
      title: launch.title,
      description: launch.description
    };
  }

  async getTodoById({ todoId }) {
    const response = await this.get('todos', { id: todoId });
    return this.todoReducer(response[0]);
  }
  
//   getLaunchesByIds({ launchIds }) {
//     return Promise.all(
//       launchIds.map(launchId => this.getLaunchById({ launchId })),
//     );
//   }
}


module.exports = TodoAPI;